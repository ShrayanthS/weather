const getWeather = async () => {
    const city = document.getElementById('inputValue').value.trim();
    const nameVal = document.getElementById('name');
    const temp = document.getElementById('temp');
    const desc = document.getElementById('desc');
    const tipEl = document.getElementById('tip'); 
    const weatherIcon = document.getElementById('weathericon');

    if (!city) {
        alert("Don't keep the search bar empty, Please do enter a city name!!!!");
        return;
    }

    try {
        const response = await fetch(`https://api.openweathermap.org/data/2.5/weather?q=${city}&units=metric&appid=a2c2f6f87d64ff29fa0bf08ad41b5cc4`);

        if (!response.ok) {
            throw new Error("Hi, This is Your Sky Scan Weather Assistant                                        Please do check for spelling mistake, Please make sure you enter the correct city name in the search bar.                                                                                                                                                                     Thanking You, Sky Scan Weather Assistant!!");
        }

        const data = await response.json();

      
        nameVal.innerText = data.name;
        temp.innerText = `${data.main.temp}°C`;

        const weatherMain = data.weather[0].main;
        const description = data.weather[0].description;

     
        const iconMap = {
            Clear: {
                icon: "https://cdn-icons-png.flaticon.com/512/869/869869.png",
                text: "It's a bright and sunny day! ☀️",
                tip: "Wear sunglasses and stay hydrated. Use sunscreen to protect your skin."
            },
            Clouds: {
                icon: "https://cdn-icons-png.flaticon.com/512/1163/1163624.png",
                text: "Looks like it's cloudy outside. ☁️",
                tip: "Great weather for outdoor walks, but keep an umbrella handy just in case."
            },
            Rain: {
                icon: "https://cdn-icons-png.flaticon.com/512/1163/1163657.png",
                text: "It's raining! Don't forget your umbrella. 🌧️",
                tip: "Carry an umbrella or raincoat. Watch out for slippery roads."
            },
            Snow: {
                icon: "https://cdn-icons-png.flaticon.com/512/642/642102.png",
                text: "Snow is falling! Stay warm. ❄️",
                tip: "Wear warm clothes and non-slip boots. Drive slowly on icy roads."
            },
            Drizzle: {
                icon: "https://cdn-icons-png.flaticon.com/512/4834/4834551.png",
                text: "Light drizzle is on the way. ☔",
                tip: "Keep an umbrella nearby. Roads might still be slippery."
            },
            Thunderstorm: {
                icon: "https://cdn-icons-png.flaticon.com/512/1146/1146869.png",
                text: "Thunderstorms! Stay safe indoors. ⛈️",
                tip: "Avoid going outside. Stay away from trees, poles, and electrical wires."
            },
            Mist: {
                icon: "https://cdn-icons-png.flaticon.com/512/4005/4005901.png",
                text: "Misty weather ahead. Drive carefully! 🌫️",
                tip: "Use fog lights while driving and maintain a slow speed."
            }
        };

        if (iconMap[weatherMain]) {
            weatherIcon.src = iconMap[weatherMain].icon;
            weatherIcon.style.display = "inline-block";

            desc.innerText = `${description}\n${iconMap[weatherMain].text}`;
            tipEl.innerText = iconMap[weatherMain].tip;
        } else {
            weatherIcon.style.display = "none";
            desc.innerText = description;
            tipEl.innerText = "";
        }

        let bgImage = "";
        switch (weatherMain) {
            case "Clear":
                bgImage = "url('https://media.istockphoto.com/id/476263042/photo/fluffy-clouds-in-the-sky.jpg?s=612x612&w=0&k=20&c=XcNQ8dq2FhC518Ef1hkOwrblUz5GxVhBo-AYuHV6fFI=')";
                break;
            case "Clouds":
                bgImage = "url('https://t4.ftcdn.net/jpg/05/13/26/73/360_F_513267391_QEmNGeOFLLqrILTnoq21dReUPp5UsoNr.jpg')";
                break;
            case "Rain":
                bgImage = "url('https://img.freepik.com/free-photo/weather-effects-composition_23-2149853295.jpg?semt=ais_hybrid&w=740&q=80')";
                break;
            case "Snow":
                bgImage = "url('https://wjla.com/resources/media2/16x9/full/1015/center/80/be94f27f-c70a-4e6c-b3cc-9a448da929b8-large16x9_SnowfallsinEllicottCityVeronicaJohnson.JPG')";
                break;
            case "Drizzle":
                bgImage = "url('https://www.shutterstock.com/image-photo/drizzle-on-windshield-evening-600nw-667415725.jpg')";
                break;
            case "Thunderstorm":
                bgImage = "url('https://ambientweather.com/media/blog/pexels-alexandre-bringer-3637060-_1_.jpg')";
                break;
            case "Mist":
                bgImage = "url('https://www.shutterstock.com/image-photo/landscape-heavy-foggy-road-winter-260nw-1594521517.jpg')";
                break;
            default:
                bgImage = "url('https://media.istockphoto.com/id/157592559/photo/green-landscape.jpg?s=612x612&w=0&k=20&c=dfieVqumfZZ2F3Y3cCi1w2LnkuWIZabjsjT3KcL32_0=')";
        }

        document.body.style.background = `${bgImage} no-repeat center center fixed`;
        document.body.style.backgroundSize = "cover";

    } catch (error) {
        nameVal.innerText = "";
        temp.innerText = "";
        desc.innerText = "";
        tipEl.innerText = "";
        weatherIcon.style.display = "none";
        document.body.style.background = "rgb(224, 203, 120)"; 

        alert(error.message);
    }
};

document.getElementById('button').addEventListener('click', getWeather);
